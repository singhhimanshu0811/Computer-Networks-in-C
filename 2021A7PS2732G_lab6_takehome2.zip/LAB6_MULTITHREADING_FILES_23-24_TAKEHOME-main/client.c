    #include <sys/socket.h>
    #include <sys/types.h>
    #include <stdio.h>
    #include <netinet/in.h>
    #include <errno.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <arpa/inet.h>
    #include <pthread.h>
    #include <stdbool.h>
    #include<sys/stat.h>
    pthread_t threads[2];
    // Create a connection to the server
    int flag=0;
    int create_connection(char* addr, int port) 
    {	
    	int client_sockfd;
    	// 1. SOCKET
        if((client_sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)		
    	{
            perror("client: socket");
            fflush(stdout);
            exit(1);
        }
     
    	// NO BIND NECESSARY IN CLIENT!!!
     
    	struct sockaddr_in server_addrinfo;			
        server_addrinfo.sin_family = AF_INET;		
        server_addrinfo.sin_port = htons(port);	
     
        if(inet_pton(AF_INET, addr, &server_addrinfo.sin_addr) <= 0)
    	{
            printf("\nInvalid address/ Address not supported \n");
            close(client_sockfd);
            exit(1);
        }
     
     
    	// 2. CONNECT
        if(connect(client_sockfd, (struct sockaddr*)&server_addrinfo, sizeof(server_addrinfo)) == -1)
    	{ // client connects if server port has started listen()ing and queue is non-full; however server connects to client only when it accept()s
            
    		printf("Could not find server");	
            close(client_sockfd);
            exit(1);
        }
        
     
    	return client_sockfd;	
    }
     
    void* send_data(void* args) 
    {
    	while(true){
            char msg[1024];
            memset(msg, 0, 1024);
            int socket_id=*(int*)args;
        
            fgets(msg, 1024, stdin);
            int k=strlen(msg);
            msg[k-1]='\0';
            //printf("msg is %s", msg);	

            int send_count;
            if((send_count = send(socket_id, msg, sizeof(msg), 0)) == -1)	
            {
                perror("send");
                fflush(stdout);
                exit(1);
    	    }
            if(strncmp(msg, "HISF:", 5)==0){
                flag=1;
            }
            if(strcmp(msg, "EXIT\n")==0){
                break;
            }
        }
        pthread_exit(NULL);
    }
     
    
//     void* recv_data(void *args) {
//     int socket_id = *(int*)args;
//     char reply[1024];
//     char filename[1024];
//     char current_char;
//     FILE *fp = NULL; // File pointer

//     while (1) {
//         // Receive message
//         memset(reply, 0, sizeof(reply));
        
//         if(!flag){ (recv(socket_id, reply, sizeof(reply), 0) == -1) {
//             perror("recv");
//             fflush(stdout);
//             exit(1);
//         }}

//         // Check for disconnection
//         if (strlen(reply) == 0) {
//             break;
//         }
//         if(strlen(reply)>1)printf("%s\n", reply);
//         if(flag){
//             if (recv(socket_id, reply, 5, 0) == -1) {
//             perror("recv");
//             fflush(stdout);
//             exit(1);
//             }
//             flag=0;
//         }
//         if (strncmp(reply, "START", 5) == 0) {
//             // Receive filename
//             printf("entered start\n");
//             fflush(stdout);
//             memset(filename, 0, sizeof(filename));
            
//             if (recv(socket_id, filename, sizeof(filename), 0) == -1) {
//                 perror("recv");
//                 fflush(stdout);
//                 exit(1);
//             }

//             // Create directory (if it doesn't exist)
//             if (mkdir("client_files", 0777) == -1 && errno != EEXIST) {
//                 perror("mkdir");
//                 // Handle directory creation error
//                 continue;
//             }

//             // Create file path
//             char filepath[2048];
//             snprintf(filepath, sizeof(filepath), "client_files/%s", filename);
//             printf("%s", filename);
//             fflush(stdout);

//             // Open file for writing
//             fp = fopen(filepath, "a");
//             //fseek();
//             if (fp == NULL) {
//                 perror("fopen");
//                 // Handle file opening error
//                 continue;
//             }

//             printf("Receiving file: %s\n", filename);

//         } 
//         else if (strcmp(reply, "END") == 0) {
//             printf("entered end\n");
//             fflush(stdout);
//             if (fp != NULL) {
//                 fclose(fp);
//                 fp = NULL;
//                 printf("File received successfully: %s\n", filename);
//             } else {
//                 printf("No file transfer in progress.\n");
//             }
//             fclose(fp);
//         } 
//         else {
//             // Write received data to file
//             if (fp != NULL) {
//                 int bytes_written = fwrite(reply, sizeof(char), strlen(reply), fp);
//                 if (bytes_written != strlen(reply)) {
//                     perror("fwrite");
//                     // Handle file writing error
//                     fclose(fp);
//                     fp = NULL;
//                     break;
//                 }
//             } else {
//                 continue;
//                 //printf("No file open to write data.\n");
//             }
//         }

//         // Print received message (excluding final newline)
//         for (int i = 0; i < strlen(reply) - 1; i++) {
//             printf("%c", reply[i]);
//         }
//         fflush(stdout);
//     }

//     pthread_exit(NULL);
// }
    void* recv_data(void *args){
        int socket_id=*(int*)args;
        char reply[1024];
        FILE* fp;
        char filepath[1000]={0};
        strcat(filepath, "client_files/");
        while(1){
            if(flag){
                int recv_count=0;
                recv_count=recv(socket_id, reply, 5, 0);
                if(recv_count==0 ||recv_count<0)continue;
                printf("%s; is the reply\n", reply);
                fflush(stdout);
                
                fp=fopen(filepath, "a");
               // printf("%s\n is the filepath\n", filepath);
                if(fp==NULL)printf("abhi bhi null?\n");
                fprintf(fp, "%s", reply);
                fclose(fp);

            
            }
            else{
                int recv_count=recv(socket_id, reply, sizeof(reply), 0);
                if(recv_count==0 ||recv_count<0){
                    continue;
                }
                if(flag){
                    strcat(filepath, &reply[5]);
                }
                
                printf("%s is the normal reply\n", reply);
                memset(reply, 0, sizeof(reply));
            }
        }
        pthread_exit(NULL);
    }



     
    int main(int argc, char *argv[])
    {
        if (argc != 3)
    	{
    		printf("Use 2 cli arguments\n");
    		return -1;
    	}
        
    	// extract the address and port from the command line arguments
     
    	char addr[INET6_ADDRSTRLEN];	
    	strcpy(addr, argv[1]);
     
    	unsigned int port;				
    	port = atoi(argv[2]);

        
     
    	int socket_id = create_connection(addr, port);
        
            int *client_sockfd_ptr = malloc(sizeof(int));;
            *client_sockfd_ptr = socket_id;	
        
            if(pthread_create(&threads[0], NULL, send_data, client_sockfd_ptr)!=0){
                perror("pthread_create failed");
                fflush(stdout);
                close(socket_id);
            }
            
            
            if(pthread_create(&threads[1], NULL, recv_data, client_sockfd_ptr)!=0){
                perror("pthread_create failed");
                fflush(stdout);
                close(socket_id);

            }

            for (int i = 0; i < 2; i++) {
                if(pthread_join(threads[i], NULL) != 0) {
                    perror("pthread_join failed");
                    fflush(stdout);
                    return -1;
                }
            }

        // Close socket and free memory
            close(socket_id);
            free(client_sockfd_ptr);
            return 0;
       
    }